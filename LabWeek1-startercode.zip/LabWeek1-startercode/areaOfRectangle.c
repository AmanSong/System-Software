#include <stdio.h>

int areaOfRectangle(int side1, int side2) 
{
    int area = side1 * side2;
    printf("The area of the rectangle is %d\n", area);
    return area;
}