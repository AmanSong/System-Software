#ifndef AREAOFRECTANGLE_H_
#define AREAOFRECTANGLE_H_

int areaOfRectangle(int side1, int side2);

#endif