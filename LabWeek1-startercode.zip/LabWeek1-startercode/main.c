#include <stdio.h>
#include "areaOfRectangle.h"

int main(int argc, char **argv) 
{
    areaOfRectangle(8,9);
}